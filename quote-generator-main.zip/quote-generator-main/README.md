# Quote Generator

<img width="1089" alt="Screen Shot 2022-12-06 at 2 33 12 PM" src="https://user-images.githubusercontent.com/68920695/206017265-a0f0a020-795a-42e3-a3b4-63620fb6b2d1.png">

## Description

Application that generates random quotes by the press of a button.  The user can also choose to tweet the quote from the application.

## Built With

- HTML
- CSS
- JavaScript

## Live Version

https://jamesivdeveloper.github.io/quote-generator/
